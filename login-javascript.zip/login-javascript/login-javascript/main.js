        toastr.options = {
            "closeButton": true,
            "debug": false,
            "newestOnTop": true,
            "progressBar": true,
            "positionClass": "toast-bottom-center",
            "preventDuplicates": false,
            "onclick": null,
            "showDuration": "300",
            "hideDuration": "1000",
            "timeOut": "5000", 
            "extendedTimeOut": "1000",
            "showEasing": "swing",
            "hideEasing": "linear",
            "showMethod": "fadeIn",
            "hideMethod": "fadeOut"
        };
        const nombre = document.querySelector("#nombre");
        const apellido = document.querySelector("#apellido");
        const usuario = document.querySelector("#username");
        const telefono = document.querySelector("#telefono");
        const password = document.querySelector("#password");
        const confirmPassword = document.querySelector("#confirm_password");
        const btn = document.querySelector("#btnSubmit");

        btn.addEventListener("click", function(event) {
            let valid = true;

            // Validación de nombre
            if (nombre.value == "") {
                event.preventDefault();
                nombre.classList.add("errorField");
                toastr.error('Por favor, completa el campo de nombres.');
                valid = false;
            } else {
                nombre.classList.remove("errorField");
            }

            // Validación de apellido
            if (valid && apellido.value == "") {
                event.preventDefault();
                apellido.classList.add("errorField");
                toastr.error('Por favor, completa el campo de apellidos.');
                valid = false;
            } else {
                apellido.classList.remove("errorField");
            }

            // Validación de nombre de usuario
            if (valid && (usuario.value == "" || !/^[a-zA-Z0-9]+$/.test(usuario.value))) {
                event.preventDefault();
                usuario.classList.add("errorField");
                toastr.error('El nombre de usuario solo puede contener letras y números.');
                valid = false;
            } else {
                usuario.classList.remove("errorField");
            }

            // Validación de teléfono
            if (valid && (telefono.value == "" || !/^\d{10}$/.test(telefono.value))) {
                event.preventDefault();
                telefono.classList.add("errorField");
                toastr.error('Por favor, introduce un número de teléfono válido (10 dígitos).');
                valid = false;
            } else {
                telefono.classList.remove("errorField");
            }

            // Validación de contraseña
            if (valid && password.value.length < 8) {
                event.preventDefault();
                password.classList.add("errorField");
                toastr.error('La contraseña debe tener al menos 8 caracteres.');
                valid = false;
            } else {
                password.classList.remove("errorField");
            }

            // Validación de confirmación de contraseña
            if (valid && confirmPassword.value == "") {
                event.preventDefault();
                confirmPassword.classList.add("errorField");
                toastr.error('Por favor, confirma tu contraseña.');
                valid = false;
            } else {
                confirmPassword.classList.remove("errorField");
            }

            // Verifica si las contraseñas coinciden
            if (valid && password.value !== confirmPassword.value) {
                event.preventDefault();
                confirmPassword.classList.add("errorField");
                toastr.error('Las contraseñas no coinciden.');
                valid = false;
            } else {
                confirmPassword.classList.remove("errorField");
            }
        });